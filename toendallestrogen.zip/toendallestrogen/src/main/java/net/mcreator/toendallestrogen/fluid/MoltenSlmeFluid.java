
package net.mcreator.toendallestrogen.fluid;

import net.minecraftforge.fluids.ForgeFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.ParticleOptions;

import net.mcreator.toendallestrogen.init.ToendallestrogenModItems;
import net.mcreator.toendallestrogen.init.ToendallestrogenModFluids;
import net.mcreator.toendallestrogen.init.ToendallestrogenModFluidTypes;
import net.mcreator.toendallestrogen.init.ToendallestrogenModBlocks;

public abstract class MoltenSlmeFluid extends ForgeFlowingFluid {
	public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(() -> ToendallestrogenModFluidTypes.MOLTEN_SLIME_TYPE.get(), () -> ToendallestrogenModFluids.MOLTEN_SLIME.get(),
			() -> ToendallestrogenModFluids.FLOWING_MOLTEN_SLIME.get()).explosionResistance(100f).tickRate(60).levelDecreasePerBlock(2).slopeFindDistance(3).bucket(() -> ToendallestrogenModItems.MOLTEN_SLIME_BUCKET.get())
			.block(() -> (LiquidBlock) ToendallestrogenModBlocks.MOLTEN_SLIME.get());

	private MoltenSlmeFluid() {
		super(PROPERTIES);
	}

	@Override
	public ParticleOptions getDripParticle() {
		return ParticleTypes.ITEM_SLIME;
	}

	public static class Source extends MoltenSlmeFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends MoltenSlmeFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}
