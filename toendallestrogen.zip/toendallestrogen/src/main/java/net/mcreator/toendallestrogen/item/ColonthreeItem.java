
package net.mcreator.toendallestrogen.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class ColonthreeItem extends Item {
	public ColonthreeItem() {
		super(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC));
	}
}
