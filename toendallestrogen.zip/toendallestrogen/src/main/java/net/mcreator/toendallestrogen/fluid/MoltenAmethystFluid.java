
package net.mcreator.toendallestrogen.fluid;

import net.minecraftforge.fluids.ForgeFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;

import net.mcreator.toendallestrogen.init.ToendallestrogenModItems;
import net.mcreator.toendallestrogen.init.ToendallestrogenModFluids;
import net.mcreator.toendallestrogen.init.ToendallestrogenModFluidTypes;
import net.mcreator.toendallestrogen.init.ToendallestrogenModBlocks;

public abstract class MoltenAmethystFluid extends ForgeFlowingFluid {
	public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(() -> ToendallestrogenModFluidTypes.MOLTEN_AMETHYST_TYPE.get(), () -> ToendallestrogenModFluids.MOLTEN_AMETHYST.get(),
			() -> ToendallestrogenModFluids.FLOWING_MOLTEN_AMETHYST.get()).explosionResistance(100f).bucket(() -> ToendallestrogenModItems.MOLTEN_AMETHYST_BUCKET.get()).block(() -> (LiquidBlock) ToendallestrogenModBlocks.MOLTEN_AMETHYST.get());

	private MoltenAmethystFluid() {
		super(PROPERTIES);
	}

	public static class Source extends MoltenAmethystFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends MoltenAmethystFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}
