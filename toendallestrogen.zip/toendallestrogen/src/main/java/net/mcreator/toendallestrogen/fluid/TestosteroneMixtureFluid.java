
package net.mcreator.toendallestrogen.fluid;

import net.minecraftforge.fluids.ForgeFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;

import net.mcreator.toendallestrogen.init.ToendallestrogenModItems;
import net.mcreator.toendallestrogen.init.ToendallestrogenModFluids;
import net.mcreator.toendallestrogen.init.ToendallestrogenModFluidTypes;
import net.mcreator.toendallestrogen.init.ToendallestrogenModBlocks;

public abstract class TestosteroneMixtureFluid extends ForgeFlowingFluid {
	public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(() -> ToendallestrogenModFluidTypes.TESTOSTERONE_MIXTURE_TYPE.get(), () -> ToendallestrogenModFluids.TESTOSTERONE_MIXTURE.get(),
			() -> ToendallestrogenModFluids.FLOWING_TESTOSTERONE_MIXTURE.get()).explosionResistance(100f).bucket(() -> ToendallestrogenModItems.TESTOSTERONE_MIXTURE_BUCKET.get())
			.block(() -> (LiquidBlock) ToendallestrogenModBlocks.TESTOSTERONE_MIXTURE.get());

	private TestosteroneMixtureFluid() {
		super(PROPERTIES);
	}

	public static class Source extends TestosteroneMixtureFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends TestosteroneMixtureFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}
