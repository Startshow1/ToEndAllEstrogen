
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.toendallestrogen.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.toendallestrogen.item.UsedFilterItem;
import net.mcreator.toendallestrogen.item.UrineItem;
import net.mcreator.toendallestrogen.item.TestosteronePowderItem;
import net.mcreator.toendallestrogen.item.TestosteronePillItem;
import net.mcreator.toendallestrogen.item.TestosteroneMixtureItem;
import net.mcreator.toendallestrogen.item.TestosteroneChunkItem;
import net.mcreator.toendallestrogen.item.MoltenSlmeItem;
import net.mcreator.toendallestrogen.item.MoltenAmethystItem;
import net.mcreator.toendallestrogen.item.LiquidEstrogenItem;
import net.mcreator.toendallestrogen.item.IncompleteColonthreeItem;
import net.mcreator.toendallestrogen.item.HorseUrineBottleItem;
import net.mcreator.toendallestrogen.item.GenderFluidItem;
import net.mcreator.toendallestrogen.item.FilteredUrineItem;
import net.mcreator.toendallestrogen.item.EstrogenPillItem;
import net.mcreator.toendallestrogen.item.CrystalEstrogenPillItem;
import net.mcreator.toendallestrogen.item.ColonthreeItem;
import net.mcreator.toendallestrogen.item.BallsItem;
import net.mcreator.toendallestrogen.ToendallestrogenMod;

public class ToendallestrogenModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, ToendallestrogenMod.MODID);
	public static final RegistryObject<Item> HORSE_URINE_BOTTLE = REGISTRY.register("horse_urine_bottle", () -> new HorseUrineBottleItem());
	public static final RegistryObject<Item> ESTROGEN_PILL = REGISTRY.register("estrogen_pill", () -> new EstrogenPillItem());
	public static final RegistryObject<Item> USED_FILTER = REGISTRY.register("used_filter", () -> new UsedFilterItem());
	public static final RegistryObject<Item> GENDER_FLUID_BUCKET = REGISTRY.register("gender_fluid_bucket", () -> new GenderFluidItem());
	public static final RegistryObject<Item> ESTROGEN_PILL_BLOCK = block(ToendallestrogenModBlocks.ESTROGEN_PILL_BLOCK);
	public static final RegistryObject<Item> BALLS = REGISTRY.register("balls", () -> new BallsItem());
	public static final RegistryObject<Item> COLONTHREE = REGISTRY.register("colonthree", () -> new ColonthreeItem());
	public static final RegistryObject<Item> URINE_BUCKET = REGISTRY.register("urine_bucket", () -> new UrineItem());
	public static final RegistryObject<Item> FILTERED_URINE_BUCKET = REGISTRY.register("filtered_urine_bucket", () -> new FilteredUrineItem());
	public static final RegistryObject<Item> LIQUID_ESTROGEN_BUCKET = REGISTRY.register("liquid_estrogen_bucket", () -> new LiquidEstrogenItem());
	public static final RegistryObject<Item> TESTOSTERONE_PILL_BLOCK = block(ToendallestrogenModBlocks.TESTOSTERONE_PILL_BLOCK);
	public static final RegistryObject<Item> MOLTEN_SLIME_BUCKET = REGISTRY.register("molten_slime_bucket", () -> new MoltenSlmeItem());
	public static final RegistryObject<Item> TESTOSTERONE_CHUNK = REGISTRY.register("testosterone_chunk", () -> new TestosteroneChunkItem());
	public static final RegistryObject<Item> TESTOSTERONE_MIXTURE_BUCKET = REGISTRY.register("testosterone_mixture_bucket", () -> new TestosteroneMixtureItem());
	public static final RegistryObject<Item> TESTOSTERONE_POWDER = REGISTRY.register("testosterone_powder", () -> new TestosteronePowderItem());
	public static final RegistryObject<Item> MOLTEN_AMETHYST_BUCKET = REGISTRY.register("molten_amethyst_bucket", () -> new MoltenAmethystItem());
	public static final RegistryObject<Item> CRYSTAL_ESTROGEN_PILL = REGISTRY.register("crystal_estrogen_pill", () -> new CrystalEstrogenPillItem());
	public static final RegistryObject<Item> INCOMPLETE_COLONTHREE = REGISTRY.register("incomplete_colonthree", () -> new IncompleteColonthreeItem());
	public static final RegistryObject<Item> TESTOSTERONE_PILL = REGISTRY.register("testosterone_pill", () -> new TestosteronePillItem());

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
