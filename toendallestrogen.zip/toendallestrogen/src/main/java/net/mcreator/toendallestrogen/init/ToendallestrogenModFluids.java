
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.toendallestrogen.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FlowingFluid;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.ItemBlockRenderTypes;

import net.mcreator.toendallestrogen.fluid.UrineFluid;
import net.mcreator.toendallestrogen.fluid.TestosteroneMixtureFluid;
import net.mcreator.toendallestrogen.fluid.MoltenSlmeFluid;
import net.mcreator.toendallestrogen.fluid.MoltenAmethystFluid;
import net.mcreator.toendallestrogen.fluid.LiquidEstrogenFluid;
import net.mcreator.toendallestrogen.fluid.GenderFluidFluid;
import net.mcreator.toendallestrogen.fluid.FilteredUrineFluid;
import net.mcreator.toendallestrogen.ToendallestrogenMod;

public class ToendallestrogenModFluids {
	public static final DeferredRegister<Fluid> REGISTRY = DeferredRegister.create(ForgeRegistries.FLUIDS, ToendallestrogenMod.MODID);
	public static final RegistryObject<FlowingFluid> GENDER_FLUID = REGISTRY.register("gender_fluid", () -> new GenderFluidFluid.Source());
	public static final RegistryObject<FlowingFluid> FLOWING_GENDER_FLUID = REGISTRY.register("flowing_gender_fluid", () -> new GenderFluidFluid.Flowing());
	public static final RegistryObject<FlowingFluid> URINE = REGISTRY.register("urine", () -> new UrineFluid.Source());
	public static final RegistryObject<FlowingFluid> FLOWING_URINE = REGISTRY.register("flowing_urine", () -> new UrineFluid.Flowing());
	public static final RegistryObject<FlowingFluid> FILTERED_URINE = REGISTRY.register("filtered_urine", () -> new FilteredUrineFluid.Source());
	public static final RegistryObject<FlowingFluid> FLOWING_FILTERED_URINE = REGISTRY.register("flowing_filtered_urine", () -> new FilteredUrineFluid.Flowing());
	public static final RegistryObject<FlowingFluid> LIQUID_ESTROGEN = REGISTRY.register("liquid_estrogen", () -> new LiquidEstrogenFluid.Source());
	public static final RegistryObject<FlowingFluid> FLOWING_LIQUID_ESTROGEN = REGISTRY.register("flowing_liquid_estrogen", () -> new LiquidEstrogenFluid.Flowing());
	public static final RegistryObject<FlowingFluid> MOLTEN_SLIME = REGISTRY.register("molten_slime", () -> new MoltenSlmeFluid.Source());
	public static final RegistryObject<FlowingFluid> FLOWING_MOLTEN_SLIME = REGISTRY.register("flowing_molten_slime", () -> new MoltenSlmeFluid.Flowing());
	public static final RegistryObject<FlowingFluid> TESTOSTERONE_MIXTURE = REGISTRY.register("testosterone_mixture", () -> new TestosteroneMixtureFluid.Source());
	public static final RegistryObject<FlowingFluid> FLOWING_TESTOSTERONE_MIXTURE = REGISTRY.register("flowing_testosterone_mixture", () -> new TestosteroneMixtureFluid.Flowing());
	public static final RegistryObject<FlowingFluid> MOLTEN_AMETHYST = REGISTRY.register("molten_amethyst", () -> new MoltenAmethystFluid.Source());
	public static final RegistryObject<FlowingFluid> FLOWING_MOLTEN_AMETHYST = REGISTRY.register("flowing_molten_amethyst", () -> new MoltenAmethystFluid.Flowing());

	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class FluidsClientSideHandler {
		@SubscribeEvent
		public static void clientSetup(FMLClientSetupEvent event) {
			ItemBlockRenderTypes.setRenderLayer(GENDER_FLUID.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_GENDER_FLUID.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(URINE.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_URINE.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FILTERED_URINE.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_FILTERED_URINE.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(LIQUID_ESTROGEN.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_LIQUID_ESTROGEN.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(MOLTEN_SLIME.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_MOLTEN_SLIME.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(TESTOSTERONE_MIXTURE.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_TESTOSTERONE_MIXTURE.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(MOLTEN_AMETHYST.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_MOLTEN_AMETHYST.get(), RenderType.translucent());
		}
	}
}
