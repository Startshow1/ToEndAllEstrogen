
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.toendallestrogen.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;

import net.mcreator.toendallestrogen.ToendallestrogenMod;

public class ToendallestrogenModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, ToendallestrogenMod.MODID);
	public static final RegistryObject<SoundEvent> PILLBLOCK_BREAK = REGISTRY.register("pillblock.break", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("toendallestrogen", "pillblock.break")));
	public static final RegistryObject<SoundEvent> PILLBLOCK_PLACE = REGISTRY.register("pillblock.place", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("toendallestrogen", "pillblock.place")));
	public static final RegistryObject<SoundEvent> PILLBLOCK_STEP = REGISTRY.register("pillblock.step", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("toendallestrogen", "pillblock.step")));
}
