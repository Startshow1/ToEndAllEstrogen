
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.toendallestrogen.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fluids.FluidType;

import net.mcreator.toendallestrogen.fluid.types.UrineFluidType;
import net.mcreator.toendallestrogen.fluid.types.TestosteroneMixtureFluidType;
import net.mcreator.toendallestrogen.fluid.types.MoltenSlmeFluidType;
import net.mcreator.toendallestrogen.fluid.types.MoltenAmethystFluidType;
import net.mcreator.toendallestrogen.fluid.types.LiquidEstrogenFluidType;
import net.mcreator.toendallestrogen.fluid.types.GenderFluidFluidType;
import net.mcreator.toendallestrogen.fluid.types.FilteredUrineFluidType;
import net.mcreator.toendallestrogen.ToendallestrogenMod;

public class ToendallestrogenModFluidTypes {
	public static final DeferredRegister<FluidType> REGISTRY = DeferredRegister.create(ForgeRegistries.Keys.FLUID_TYPES, ToendallestrogenMod.MODID);
	public static final RegistryObject<FluidType> GENDER_FLUID_TYPE = REGISTRY.register("gender_fluid", () -> new GenderFluidFluidType());
	public static final RegistryObject<FluidType> URINE_TYPE = REGISTRY.register("urine", () -> new UrineFluidType());
	public static final RegistryObject<FluidType> FILTERED_URINE_TYPE = REGISTRY.register("filtered_urine", () -> new FilteredUrineFluidType());
	public static final RegistryObject<FluidType> LIQUID_ESTROGEN_TYPE = REGISTRY.register("liquid_estrogen", () -> new LiquidEstrogenFluidType());
	public static final RegistryObject<FluidType> MOLTEN_SLIME_TYPE = REGISTRY.register("molten_slime", () -> new MoltenSlmeFluidType());
	public static final RegistryObject<FluidType> TESTOSTERONE_MIXTURE_TYPE = REGISTRY.register("testosterone_mixture", () -> new TestosteroneMixtureFluidType());
	public static final RegistryObject<FluidType> MOLTEN_AMETHYST_TYPE = REGISTRY.register("molten_amethyst", () -> new MoltenAmethystFluidType());
}
