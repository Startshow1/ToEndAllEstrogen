
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.toendallestrogen.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.toendallestrogen.ToendallestrogenMod;

public class ToendallestrogenModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ToendallestrogenMod.MODID);
	public static final RegistryObject<CreativeModeTab> ESTROGEN = REGISTRY.register("estrogen",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.toendallestrogen.estrogen")).icon(() -> new ItemStack(ToendallestrogenModItems.ESTROGEN_PILL.get())).displayItems((parameters, tabData) -> {
				tabData.accept(ToendallestrogenModItems.ESTROGEN_PILL.get());
				tabData.accept(ToendallestrogenModItems.USED_FILTER.get());
				tabData.accept(ToendallestrogenModItems.GENDER_FLUID_BUCKET.get());
				tabData.accept(ToendallestrogenModBlocks.ESTROGEN_PILL_BLOCK.get().asItem());
				tabData.accept(ToendallestrogenModItems.BALLS.get());
				tabData.accept(ToendallestrogenModItems.COLONTHREE.get());
				tabData.accept(ToendallestrogenModItems.FILTERED_URINE_BUCKET.get());
				tabData.accept(ToendallestrogenModItems.LIQUID_ESTROGEN_BUCKET.get());
				tabData.accept(ToendallestrogenModBlocks.TESTOSTERONE_PILL_BLOCK.get().asItem());
				tabData.accept(ToendallestrogenModItems.MOLTEN_SLIME_BUCKET.get());
				tabData.accept(ToendallestrogenModItems.TESTOSTERONE_CHUNK.get());
				tabData.accept(ToendallestrogenModItems.TESTOSTERONE_MIXTURE_BUCKET.get());
				tabData.accept(ToendallestrogenModItems.TESTOSTERONE_POWDER.get());
				tabData.accept(ToendallestrogenModItems.MOLTEN_AMETHYST_BUCKET.get());
				tabData.accept(ToendallestrogenModItems.CRYSTAL_ESTROGEN_PILL.get());
				tabData.accept(ToendallestrogenModItems.TESTOSTERONE_PILL.get());
			}).build());
}
