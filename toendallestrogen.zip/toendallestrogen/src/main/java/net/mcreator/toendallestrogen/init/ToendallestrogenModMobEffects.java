
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.toendallestrogen.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.effect.MobEffect;

import net.mcreator.toendallestrogen.potion.GirlPowerMobEffect;
import net.mcreator.toendallestrogen.ToendallestrogenMod;

public class ToendallestrogenModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, ToendallestrogenMod.MODID);
	public static final RegistryObject<MobEffect> GIRL_POWER = REGISTRY.register("girl_power", () -> new GirlPowerMobEffect());
}
