
package net.mcreator.toendallestrogen.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BucketItem;

import net.mcreator.toendallestrogen.init.ToendallestrogenModFluids;

public class FilteredUrineItem extends BucketItem {
	public FilteredUrineItem() {
		super(ToendallestrogenModFluids.FILTERED_URINE, new Item.Properties().craftRemainder(Items.BUCKET).stacksTo(1).rarity(Rarity.COMMON));
	}
}
