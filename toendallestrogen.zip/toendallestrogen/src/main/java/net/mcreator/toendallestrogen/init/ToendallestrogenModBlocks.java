
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.toendallestrogen.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.toendallestrogen.block.UrineBlock;
import net.mcreator.toendallestrogen.block.TestosteronePillBlockBlock;
import net.mcreator.toendallestrogen.block.TestosteroneMixtureBlock;
import net.mcreator.toendallestrogen.block.MoltenSlmeBlock;
import net.mcreator.toendallestrogen.block.MoltenAmethystBlock;
import net.mcreator.toendallestrogen.block.LiquidEstrogenBlock;
import net.mcreator.toendallestrogen.block.GenderFluidBlock;
import net.mcreator.toendallestrogen.block.FilteredUrineBlock;
import net.mcreator.toendallestrogen.block.EtsrogenPillBlockBlock;
import net.mcreator.toendallestrogen.ToendallestrogenMod;

public class ToendallestrogenModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, ToendallestrogenMod.MODID);
	public static final RegistryObject<Block> GENDER_FLUID = REGISTRY.register("gender_fluid", () -> new GenderFluidBlock());
	public static final RegistryObject<Block> ESTROGEN_PILL_BLOCK = REGISTRY.register("estrogen_pill_block", () -> new EtsrogenPillBlockBlock());
	public static final RegistryObject<Block> URINE = REGISTRY.register("urine", () -> new UrineBlock());
	public static final RegistryObject<Block> FILTERED_URINE = REGISTRY.register("filtered_urine", () -> new FilteredUrineBlock());
	public static final RegistryObject<Block> LIQUID_ESTROGEN = REGISTRY.register("liquid_estrogen", () -> new LiquidEstrogenBlock());
	public static final RegistryObject<Block> TESTOSTERONE_PILL_BLOCK = REGISTRY.register("testosterone_pill_block", () -> new TestosteronePillBlockBlock());
	public static final RegistryObject<Block> MOLTEN_SLIME = REGISTRY.register("molten_slime", () -> new MoltenSlmeBlock());
	public static final RegistryObject<Block> TESTOSTERONE_MIXTURE = REGISTRY.register("testosterone_mixture", () -> new TestosteroneMixtureBlock());
	public static final RegistryObject<Block> MOLTEN_AMETHYST = REGISTRY.register("molten_amethyst", () -> new MoltenAmethystBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
